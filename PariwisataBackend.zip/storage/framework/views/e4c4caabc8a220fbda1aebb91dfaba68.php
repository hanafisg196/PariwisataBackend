
<!-- resources/views/map.blade.php -->
<!DOCTYPE html>
<html>
<head>
    <title>Google Maps Link</title>
</head>
<body>
    <h1>Google Maps Link</h1>
    <a href="<?php echo e($googleMapsUrl); ?>" target="_blank">Open in Google Maps</a>
</body>
</html>
<?php /**PATH C:\Project\PariwisataBackend\resources\views/dashboard/map.blade.php ENDPATH**/ ?>