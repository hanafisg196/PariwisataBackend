<div>
    

    <div class="row">
        <!--[if BLOCK]><![endif]--><?php if(!empty($images) && count($images) > 0): ?>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6">
                    <div class="card border-0 text-white">
                        <img class="card-img" src="<?php echo e(asset('storage/'.$img->image)); ?>" alt="Card" height="200" width="150">
                        <div class="card-img-overlay bg-overlay">
                            <button wire:click="deleteImage(<?php echo e($img->id); ?>)" type="button" class="btn btn-icon btn-danger waves-effect waves-float waves-light">
                                <span>X</span>
                            </button>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        <?php else: ?>
            <div class="mb-1">
                <label for="image">Not have any images for Activity! Please upload.</label>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>

</div>
<?php /**PATH C:\Project\PariwisataBackend\resources\views/livewire/delete-image.blade.php ENDPATH**/ ?>