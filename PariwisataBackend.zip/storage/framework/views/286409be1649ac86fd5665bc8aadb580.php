<?php if(session()->has('success')): ?>
    <div class="row">
        <div class="alert alert-success col-sm-3 ml-3 mb-2" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    </div>
    
<?php elseif($errors->any()): ?>
    <div class="row">
        <div class="alert alert-danger col-sm-3 ml-3 mb-2" role="alert">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH C:\Project\PariwisataBackend\resources\views/_partials/alert.blade.php ENDPATH**/ ?>