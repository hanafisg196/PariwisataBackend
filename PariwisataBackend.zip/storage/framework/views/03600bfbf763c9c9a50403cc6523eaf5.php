<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header border-bottom p-1">
        <div class="head-label"></div>
        <form action="/trip/search" method="get">
            <?php echo csrf_field(); ?>
            <div class="dt-buttons d-inline-flex">
                <input type="text" class="form-control" id="search"
                name="search" placeholder="Search" value="<?php echo e(request('search')); ?>">
                &nbsp;
                <button type="submit" class="btn btn-icon btn-primary waves-effect waves-float waves-light">
                    <span><i data-feather='search'></i></span>
                </button>
            </div>
        </form>
        <div class="dt-action-buttons text-end">
            <div class="dt-buttons d-inline-flex">
                <button type="button"
                class="btn btn-gradient-primary pull-right"
                data-bs-toggle="modal" data-bs-target="#addModal">
                <span><i
                 data-feather='plus'></i> Add Trip</span></button>
            </div>
        </div>

    </div>

    <div class="card-body mt-2">
        <div class="row">
            <?php echo $__env->make('_partials.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3">
                    <div class="card border-0 text-white">
                        <img class="card-img" src="<?php echo e(asset('storage/'. $item->cover)); ?>"
                         alt="Card" height="200">
                        <div class="card-img-overlay bg-overlay">
                            <h4 class="card-title text-white"><?php echo e($item->name); ?></h4>
                            <div class="btn-group">
                                <a type="button" class="btn btn-icon btn-warning
                                   waves-effect waves-float waves-light"
                                   data-bs-toggle="modal"
                                   data-bs-target="#editModal<?php echo e($item->id); ?>">
                                   <span><i data-feather='edit-2'></i></span>
                                </a>
                                    &nbsp;
                                    <form action="/trip/delete/<?php echo e($item->id); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-icon btn-danger
                                    waves-effect waves-float waves-light"
                                       data-bs-toggle="tooltip"
                                       data-bs-placement="top">
                                    <span><i data-feather='trash-2'></i></span>
                                        </button>
                                    </form>
                            </div>
                        </div>
                    </div>
                </div>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

             <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <div class="modal fade" id="editModal<?php echo e($item->id); ?>" tabindex="-1"
                aria-labelledby="editModalTitle<?php echo e($item->id); ?>" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="editModalTitle">Edit Trip</h5>
                                <button type="button" class="btn-close"
                                data-bs-dismiss="modal" aria-label="Close">
                            </button>
                            </div>
                            <form class="auth-login-form mt-2" action="/trip/update/<?php echo e($item->id); ?>" method="post"
                                  enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="modal-body">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <input name="id" type="hidden" value="" id="id">
                                            <div class="mb-1">
                                                <label for="name">Name</label>
                                                <input class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                placeholder="Masukan Nama Kota/Kabupaten"
                                                name="name" type="text"
                                                value="<?php echo e($item->name); ?>" id="name" required>
                                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback">
                                                    <?php echo e($message); ?>

                                                </div>
                                             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="mb-1">
                                                <label for="cover">Cover</label>
                                                <input class="form-control <?php $__errorArgs = ['cover'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                name="cover"
                                                value="<?php echo e($item->cover); ?>" id="cover" type="file">

                                                <?php $__errorArgs = ['cover'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback">
                                                    <?php echo e($message); ?>

                                                </div>
                                             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">

                                        <button type="submit"
                                                data-bs-toggle="tooltip"
                                                data-bs-placement="top"
                                                class="btn btn-gradient-primary float-end">Submit</button>

                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <div class="card-footer">
            <?php echo e($data->links()); ?>

    </div>
</div>

<div class="modal fade" id="addModal" tabindex="-1" aria-labelledby="addModalTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addModalTitle">Add Trip</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
                <form class="auth-login-form mt-2" action="/trip/add" method="post"
                      enctype="multipart/form-data">
                   <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="mb-1">
                                    <label for="name">Nama</label>
                                    <input class="form-control  <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="Masukan Nama Trip"
                                     name="name" type="text"id="name" required>

                                     <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                     <div class="invalid-feedback">
                                         <?php echo e($message); ?>

                                     </div>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                                </div>
                                <div class="mb-1">
                                    <label for="cover">Cover</label>
                                    <input class="form-control  <?php $__errorArgs = ['cover'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                     name="cover" id="cover" type="file" required>

                                     <?php $__errorArgs = ['cover'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                            <button type="submit"
                                    data-bs-toggle="tooltip"
                                    data-bs-placement="top"
                                    class="btn btn-gradient-primary float-end">
                                    Add</button>
                    </div>
                </form>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('_partials.content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Project\PariwisataBackend\resources\views/dashboard/trip.blade.php ENDPATH**/ ?>