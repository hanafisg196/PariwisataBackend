<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header border-bottom p-1">
        <div class="head-label"></div>
        <div class="dt-action-buttons text-end">
</div>

    <form class="auth-login-form mt-2" method="post"
    action="/destination/update/<?php echo e($destination->id); ?>"enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="modal-body">
            <div class="row">
                <?php echo $__env->make('_partials.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="col-md-8">
                    <div class="mb-1" id="title" style="display: block">
                        <div class="mb-1">
                            <label for="title">Title</label>
                        </div>
                        <input type="text" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                         value="<?php echo e(old('title', $destination->title)); ?>" id="title" name="title"
                          placeholder="Wisata Mandeh">
                    </div>
                </div>

                <div class="col-md-8">
                    <div class="mb-1">
                        <div class="mt-1">
                            <label for="trip_id">Trip</label>
                        </div>
                        <select name="trip_id" id="trip_id" class="form-control">
                            <?php $__currentLoopData = $trip; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemTrip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <option value="<?php echo e($itemTrip->id); ?>"
                                 > <?php echo e($itemTrip->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="mb-1" id="daerah" style="display: block">
                        <div class="mb-1">
                            <label for="daerah">Daerah</label>
                        </div>
                        <input type="text" class="form-control  <?php $__errorArgs = ['daerah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                         id="daerah" name="daerah" value="<?php echo e(old('daerah', $destination->daerah)); ?>"
                          placeholder="Nama Daerah Wisata">
                    </div>
                </div>
                <div class="col-md-8">
                <div class="mb-1">
                    <div class="mb-1">
                        <label for="cover">Cover</label>
                    </div>
                    <?php if($destination->cover): ?>
                    <div style="max-width: 380px; max-height: 300px; overflow: hidden;">
                        <img src="<?php echo e(asset('storage/'. $destination->cover)); ?>" class="thumb-preview img-fluid" alt="">
                    </div>
                  <?php else: ?>
                    <img class="cover-preview img-fluid" alt="">
                  <?php endif; ?>
                <div class="mb-1"></div>
                  <input class="form-control" name="cover" id="cover" type="file">
                </div>
                 </div>
                <div class="col-md-8">
                <div class="mb-1">
                    <div class="mb-1">
                        <label for="article">Article</label>
                    </div>
                    <input id="article" class="form-control <?php $__errorArgs = ['article'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    type="hidden" name="article" value="<?php echo e(old('article', $destination->article)); ?>">
                    <trix-editor input="article"></trix-editor>
                </div>
                </div>
                <div class="col-md-8">
                    <div class="mb-1">
                        <div class="mb-1">
                            <label for="image">Activity Image</label>
                        </div>

                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('delete-image', ['id' => $destination->id]);

$__html = app('livewire')->mount($__name, $__params, 'lw-3908565586-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

                        <div class="mb-1">
                            <div class="mb-1">
                                <label for="image">Upload Image</label>
                            </div>
                            <input class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="image" id="image" type="file" multiple>
                        </div>

                    </div>
                </div>

                 <div class="col-md-8">
                    <div class="mb-1" id="location" style="display: block">
                        <div class="mb-1">
                            <label for="location">Lokasi</label>
                        </div>
                        <input type="text" class="form-control <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        id="location" value="<?php echo e(old('location', $destination->location)); ?>" name="location"
                        placeholder="Jl. Wisata satu">
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="mb-1" id="cordinat" style="display: block">
                        <div class="mb-1">
                            <label for="cordinat">Kordinat</label>
                        </div>
                        <div class="mb-1">
                            <input type="text" class="form-control <?php $__errorArgs = ['latitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="latitude" value="<?php echo e($destination->latitude); ?>" name="latitude"
                            placeholder="latitude ex:-6.175110," required autofocus>
                        </div>
                        <div class="mb-1">
                            <input type="text" class="form-control <?php $__errorArgs = ['longitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="longitude" value="<?php echo e($destination->longitude); ?>" name="longitude"
                            placeholder="longitude ex:106.865036," required autofocus>
                        </div>


                    </div>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-gradient-primary float-end" type="submit">Update</button>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>

    FilePond.registerPlugin(FilePondPluginImagePreview);
    const inputElement = document.querySelector('input[id="image"]');
    const pond = FilePond.create(inputElement, {
    allowMultiple: true,
    server: {
        process: '/upload',
        revert: '/delete',
        headers: {
            'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
        }
    }
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('_partials.content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Project\PariwisataBackend\resources\views/dashboard/destinationupdate.blade.php ENDPATH**/ ?>