<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xl-2 col-md-4 col-sm-6">
        <div class="card text-center">
            <div class="card-body">
                <div class="avatar bg-light-info p-50 mb-1">
                    <div class="avatar-content">
                        <i data-feather="map-pin"></i>
                    </div>
                </div>
                <h2 class="fw-bolder"><?php echo e($trip); ?></h2>
                <p class="card-text">Trips</p>
            </div>
        </div>
    </div>
    <div class="col-xl-2 col-md-4 col-sm-6">
        <div class="card text-center">
            <div class="card-body">
                <div class="avatar bg-light-warning p-50 mb-1">
                    <div class="avatar-content"><i data-feather="compass"></i></div>
                </div>
                <h2 class="fw-bolder"><?php echo e($destination); ?></h2>
                <p class="card-text">Destinations</p>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('_partials.content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Project\PariwisataBackend\resources\views/dashboard/dashboard.blade.php ENDPATH**/ ?>