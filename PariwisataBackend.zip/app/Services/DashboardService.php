<?php
namespace App\Services;

interface DashboardService
{
        public function getTrip();
        public function getDestination();
}
